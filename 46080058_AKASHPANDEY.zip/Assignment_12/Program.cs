﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Assignment_12
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice = 0;
            while (choice != 5)
            {
                
                Console.WriteLine("1. Create New Directory And Files ");
                Console.WriteLine("2. Enter The Batch Deatils ");
                Console.WriteLine("3. Create Backup ");
                Console.WriteLine("4. Display The Details Of The Files ");
                Console.WriteLine("5. Exit");

                choice = int.Parse(Console.ReadLine());
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        {
                            Directory.CreateDirectory("c:\\Academy");
                            Console.WriteLine("How many City Data you want to store?");
                            int n = int.Parse(Console.ReadLine());
                            for(int i = 0; i < n; i++)
                            {
                                filecreate();
                            }
                        }
                        break;
                    case 2:
                        {
                       
                            Console.WriteLine("How many City Data you want to update?");
                            int n = int.Parse(Console.ReadLine());
                            Console.WriteLine();
                            for (int i = 0; i < n; i++)
                            {
                                dataupdate();
                            }
                        }
                        break;
                    case 3:
                        {
                            string source = @"c:\\Academy\\";
                            string dest = @"d:\\Academy\\";

                            if (!Directory.Exists(dest))
                            {
                                Directory.CreateDirectory(dest);
                            }

                            string[] files = Directory.GetDirectories(source);
                            foreach(string fil in files)
                            {
                                string path = Path.GetFileName(fil);
                                string desti = dest + path;
                                if (!Directory.Exists(desti))
                                {
                                    Directory.CreateDirectory(desti);
                                }

                                string source1 = source + path;
                                string[] filename = Directory.GetFiles(source1);
                                foreach (string fil1 in filename)
                                {
                                    string fil2 = Path.GetFileName(fil1);
                                    File.Copy(fil1, desti +"\\"+ fil2, true);
                                }
                            }
                            Console.WriteLine("Data Backup Has Been Completed Successfully ");
                            Console.WriteLine();
                        }
                        break;
                    case 4:
                        {
                            try
                            {
                                Console.WriteLine("Which City Data You Want to See?? ");
                                string city = Console.ReadLine();
                                Console.WriteLine();
                                string path = $"c:\\Academy\\{city}\\{city}.txt";
                                CopyOperation.filenotexist(path);
                                string data = File.ReadAllText(path);
                                Console.WriteLine(data);
                                Console.WriteLine();
                            }
                            catch (FileExistException e)
                            {
                                Console.WriteLine(e.Message);
                                Console.WriteLine();
                            }
                        }
                        break;
                    case 5:
                        {
                            Console.WriteLine("You Have Exit Successfully!!! ");
                            Console.WriteLine();
                        }
                        break;
                     default:
                        Console.WriteLine("Wrong Option. Try again.");
                        Console.WriteLine();
                        break;
                }

            }
        }


        static void filecreate()
        {
            Console.WriteLine("Enter City name : ");
            string city = Console.ReadLine();
            Console.WriteLine();
            Directory.CreateDirectory($"c:\\Academy\\{city}");
            FileStream sf = new FileStream($"c:\\Academy\\{city}\\{city}.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            sf.Close();
            Console.WriteLine($"{city} File Has Been Created Successfully ");
            Console.WriteLine();
        }
        static void dataupdate()
        {
            Console.WriteLine("Enter City name : ");
            string city = Console.ReadLine();
            string path = $"c:\\Academy\\{city}\\{city}.txt";
            if (File.Exists(path))
            {
                FileStream sf = new FileStream($"c:\\Academy\\{city}\\{city}.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                StreamWriter sf1 = new StreamWriter(sf);
                Console.WriteLine("Enter the student name : ");
                string s1 = Console.ReadLine();
                sf1.WriteLine(s1);
                Console.WriteLine("Enter the student phone number : ");
                int s2 = int.Parse(Console.ReadLine());
                sf1.WriteLine(s2);
                Console.WriteLine("Enter the student roll number : ");
                int s3 = int.Parse(Console.ReadLine());
                sf1.WriteLine(s3);
                sf1.Close();
                sf.Close();
                Console.WriteLine($"{city} File Has Been Updated Successfully ");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("City You Entered Does Not Exist!");
                Console.WriteLine("You Want To Add This City . Answer Yes Or No");
                string ans = Console.ReadLine();
                if (ans == "yes" || ans == "Yes")
                {
                    filecreate();
                }
                Console.WriteLine();
            }
        }

    }
}
