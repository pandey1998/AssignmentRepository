﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Assignment_12
{
    public class FileExistException : Exception
    {
        public FileExistException(String message)
            : base(message)
        {

        }
    }
    public class CopyOperation
    {
        static public void filenotexist(string path)
        {
            if (!File.Exists(path))
            {
                throw new FileExistException("Filename You Enter Does Not Exist!");
            }
        }
        static public void fileexist(string path)
        {
            if (File.Exists(path))
            {
                throw new FileExistException("Filename You Enter Already Exist!");
            }
        }
    }
}
